﻿namespace BibliotecaCORRETA
{
    partial class EditarLivro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditarLivro));
            this.dataGridViewLivro = new System.Windows.Forms.DataGridView();
            this.txtLivroEditar = new System.Windows.Forms.TextBox();
            this.txtAutorEditar = new System.Windows.Forms.TextBox();
            this.txtCodigoEditar = new System.Windows.Forms.TextBox();
            this.sdsd = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbnLivros = new System.Windows.Forms.Button();
            this.btnEditarLivro = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLivro)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewLivro
            // 
            this.dataGridViewLivro.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewLivro.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLivro.Location = new System.Drawing.Point(12, 150);
            this.dataGridViewLivro.Name = "dataGridViewLivro";
            this.dataGridViewLivro.Size = new System.Drawing.Size(424, 112);
            this.dataGridViewLivro.TabIndex = 0;
            this.dataGridViewLivro.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // txtLivroEditar
            // 
            this.txtLivroEditar.Location = new System.Drawing.Point(11, 65);
            this.txtLivroEditar.Name = "txtLivroEditar";
            this.txtLivroEditar.Size = new System.Drawing.Size(211, 20);
            this.txtLivroEditar.TabIndex = 1;
            this.txtLivroEditar.TextChanged += new System.EventHandler(this.txtLivroEditar_TextChanged);
            // 
            // txtAutorEditar
            // 
            this.txtAutorEditar.Location = new System.Drawing.Point(12, 106);
            this.txtAutorEditar.Name = "txtAutorEditar";
            this.txtAutorEditar.Size = new System.Drawing.Size(210, 20);
            this.txtAutorEditar.TabIndex = 2;
            this.txtAutorEditar.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtCodigoEditar
            // 
            this.txtCodigoEditar.Location = new System.Drawing.Point(12, 28);
            this.txtCodigoEditar.Name = "txtCodigoEditar";
            this.txtCodigoEditar.Size = new System.Drawing.Size(73, 20);
            this.txtCodigoEditar.TabIndex = 3;
            this.txtCodigoEditar.TextChanged += new System.EventHandler(this.txtCodigoEditar_TextChanged);
            // 
            // sdsd
            // 
            this.sdsd.AutoSize = true;
            this.sdsd.Location = new System.Drawing.Point(11, 9);
            this.sdsd.Name = "sdsd";
            this.sdsd.Size = new System.Drawing.Size(81, 13);
            this.sdsd.TabIndex = 4;
            this.sdsd.Text = "Código do Livro";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nome do livro";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Autor";
            // 
            // tbnLivros
            // 
            this.tbnLivros.Location = new System.Drawing.Point(324, 230);
            this.tbnLivros.Name = "tbnLivros";
            this.tbnLivros.Size = new System.Drawing.Size(102, 23);
            this.tbnLivros.TabIndex = 5;
            this.tbnLivros.Text = "Ver Livros";
            this.tbnLivros.UseVisualStyleBackColor = true;
            this.tbnLivros.Click += new System.EventHandler(this.tbnLivros_Click);
            // 
            // btnEditarLivro
            // 
            this.btnEditarLivro.Location = new System.Drawing.Point(315, 9);
            this.btnEditarLivro.Name = "btnEditarLivro";
            this.btnEditarLivro.Size = new System.Drawing.Size(126, 49);
            this.btnEditarLivro.TabIndex = 6;
            this.btnEditarLivro.Text = "Editar Livro";
            this.btnEditarLivro.UseVisualStyleBackColor = true;
            this.btnEditarLivro.Click += new System.EventHandler(this.btnEditarLivro_Click);
            // 
            // EditarLivro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(453, 274);
            this.Controls.Add(this.btnEditarLivro);
            this.Controls.Add(this.tbnLivros);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.sdsd);
            this.Controls.Add(this.txtCodigoEditar);
            this.Controls.Add(this.txtAutorEditar);
            this.Controls.Add(this.txtLivroEditar);
            this.Controls.Add(this.dataGridViewLivro);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EditarLivro";
            this.Text = "EditarLivro";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLivro)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewLivro;
        private System.Windows.Forms.TextBox txtLivroEditar;
        private System.Windows.Forms.TextBox txtAutorEditar;
        private System.Windows.Forms.TextBox txtCodigoEditar;
        private System.Windows.Forms.Label sdsd;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button tbnLivros;
        private System.Windows.Forms.Button btnEditarLivro;
    }
}