﻿namespace BibliotecaCORRETA
{
    partial class EditarCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditarCliente));
            this.txtEmailEditar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTelefoneEditar = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtRgEditar = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtEnderecoEditar = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtCpfEditar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNomeEditar = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnEditar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtEmailEditar
            // 
            this.txtEmailEditar.Location = new System.Drawing.Point(88, 205);
            this.txtEmailEditar.Name = "txtEmailEditar";
            this.txtEmailEditar.Size = new System.Drawing.Size(275, 20);
            this.txtEmailEditar.TabIndex = 9;
            this.txtEmailEditar.TextChanged += new System.EventHandler(this.txtEmailEditar_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(35, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Email:";
            // 
            // txtTelefoneEditar
            // 
            this.txtTelefoneEditar.Location = new System.Drawing.Point(88, 167);
            this.txtTelefoneEditar.Name = "txtTelefoneEditar";
            this.txtTelefoneEditar.Size = new System.Drawing.Size(136, 20);
            this.txtTelefoneEditar.TabIndex = 10;
            this.txtTelefoneEditar.TextChanged += new System.EventHandler(this.txtTelefoneEditar_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Telefone:";
            // 
            // txtRgEditar
            // 
            this.txtRgEditar.Location = new System.Drawing.Point(88, 134);
            this.txtRgEditar.Name = "txtRgEditar";
            this.txtRgEditar.Size = new System.Drawing.Size(106, 20);
            this.txtRgEditar.TabIndex = 11;
            this.txtRgEditar.TextChanged += new System.EventHandler(this.txtRgEditar_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(26, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "RG:";
            // 
            // txtEnderecoEditar
            // 
            this.txtEnderecoEditar.Location = new System.Drawing.Point(88, 56);
            this.txtEnderecoEditar.Name = "txtEnderecoEditar";
            this.txtEnderecoEditar.Size = new System.Drawing.Size(302, 20);
            this.txtEnderecoEditar.TabIndex = 12;
            this.txtEnderecoEditar.TextChanged += new System.EventHandler(this.txtEnderecoEditar_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Endereço:";
            // 
            // txtCpfEditar
            // 
            this.txtCpfEditar.Location = new System.Drawing.Point(88, 96);
            this.txtCpfEditar.Name = "txtCpfEditar";
            this.txtCpfEditar.Size = new System.Drawing.Size(177, 20);
            this.txtCpfEditar.TabIndex = 13;
            this.txtCpfEditar.TextChanged += new System.EventHandler(this.txtCpfEditar_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "CPF:";
            // 
            // txtNomeEditar
            // 
            this.txtNomeEditar.Location = new System.Drawing.Point(88, 22);
            this.txtNomeEditar.Name = "txtNomeEditar";
            this.txtNomeEditar.Size = new System.Drawing.Size(302, 20);
            this.txtNomeEditar.TabIndex = 14;
            this.txtNomeEditar.TextChanged += new System.EventHandler(this.txtNomeEditar_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Nome:";
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(461, 205);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(116, 56);
            this.btnEditar.TabIndex = 15;
            this.btnEditar.Text = "Editar Dados";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // EditarCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 275);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.txtEmailEditar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtTelefoneEditar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtRgEditar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtEnderecoEditar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtCpfEditar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNomeEditar);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EditarCliente";
            this.Text = "EditarCliente";
            this.Load += new System.EventHandler(this.EditarCliente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox txtEmailEditar;
        public System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txtTelefoneEditar;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox txtRgEditar;
        public System.Windows.Forms.Label label3;
        public System.Windows.Forms.TextBox txtEnderecoEditar;
        public System.Windows.Forms.Label label6;
        public System.Windows.Forms.TextBox txtCpfEditar;
        public System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox txtNomeEditar;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnEditar;
    }
}