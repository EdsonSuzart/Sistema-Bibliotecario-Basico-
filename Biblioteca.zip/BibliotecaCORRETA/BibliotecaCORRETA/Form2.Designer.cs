﻿namespace BibliotecaCORRETA
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.dataGridViewEditar = new System.Windows.Forms.DataGridView();
            this.txtNomeEditar = new System.Windows.Forms.TextBox();
            this.txtEndEditar = new System.Windows.Forms.TextBox();
            this.txtCpfEditar = new System.Windows.Forms.TextBox();
            this.txtRgEditar = new System.Windows.Forms.TextBox();
            this.txtTelEditar = new System.Windows.Forms.TextBox();
            this.txtEmailEditar = new System.Windows.Forms.TextBox();
            this.Nome = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCliente = new System.Windows.Forms.Button();
            this.btnEditar = new System.Windows.Forms.Button();
            this.txtIdEditar = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEditar)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewEditar
            // 
            this.dataGridViewEditar.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewEditar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEditar.GridColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridViewEditar.Location = new System.Drawing.Point(12, 212);
            this.dataGridViewEditar.Name = "dataGridViewEditar";
            this.dataGridViewEditar.Size = new System.Drawing.Size(520, 102);
            this.dataGridViewEditar.TabIndex = 0;
            this.dataGridViewEditar.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewEditar_CellContentClick);
            // 
            // txtNomeEditar
            // 
            this.txtNomeEditar.Location = new System.Drawing.Point(8, 66);
            this.txtNomeEditar.Name = "txtNomeEditar";
            this.txtNomeEditar.Size = new System.Drawing.Size(273, 20);
            this.txtNomeEditar.TabIndex = 1;
            // 
            // txtEndEditar
            // 
            this.txtEndEditar.Location = new System.Drawing.Point(8, 102);
            this.txtEndEditar.Name = "txtEndEditar";
            this.txtEndEditar.Size = new System.Drawing.Size(273, 20);
            this.txtEndEditar.TabIndex = 2;
            // 
            // txtCpfEditar
            // 
            this.txtCpfEditar.Location = new System.Drawing.Point(354, 27);
            this.txtCpfEditar.Name = "txtCpfEditar";
            this.txtCpfEditar.Size = new System.Drawing.Size(131, 20);
            this.txtCpfEditar.TabIndex = 3;
            // 
            // txtRgEditar
            // 
            this.txtRgEditar.Location = new System.Drawing.Point(354, 63);
            this.txtRgEditar.Name = "txtRgEditar";
            this.txtRgEditar.Size = new System.Drawing.Size(76, 20);
            this.txtRgEditar.TabIndex = 4;
            // 
            // txtTelEditar
            // 
            this.txtTelEditar.Location = new System.Drawing.Point(354, 101);
            this.txtTelEditar.Name = "txtTelEditar";
            this.txtTelEditar.Size = new System.Drawing.Size(104, 20);
            this.txtTelEditar.TabIndex = 5;
            // 
            // txtEmailEditar
            // 
            this.txtEmailEditar.Location = new System.Drawing.Point(9, 140);
            this.txtEmailEditar.Name = "txtEmailEditar";
            this.txtEmailEditar.Size = new System.Drawing.Size(223, 20);
            this.txtEmailEditar.TabIndex = 6;
            // 
            // Nome
            // 
            this.Nome.AutoSize = true;
            this.Nome.Location = new System.Drawing.Point(9, 47);
            this.Nome.Name = "Nome";
            this.Nome.Size = new System.Drawing.Size(35, 13);
            this.Nome.TabIndex = 7;
            this.Nome.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 89);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Endereço";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(351, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(27, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "CPF";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(351, 47);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(23, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "RG";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(351, 85);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Telefone";
            // 
            // btnCliente
            // 
            this.btnCliente.Location = new System.Drawing.Point(409, 281);
            this.btnCliente.Name = "btnCliente";
            this.btnCliente.Size = new System.Drawing.Size(110, 22);
            this.btnCliente.TabIndex = 8;
            this.btnCliente.Text = "Ver Clientes";
            this.btnCliente.UseVisualStyleBackColor = true;
            this.btnCliente.Click += new System.EventHandler(this.btnCliente_Click);
            // 
            // btnEditar
            // 
            this.btnEditar.Location = new System.Drawing.Point(394, 166);
            this.btnEditar.Name = "btnEditar";
            this.btnEditar.Size = new System.Drawing.Size(138, 40);
            this.btnEditar.TabIndex = 9;
            this.btnEditar.Text = "Editar Cliente";
            this.btnEditar.UseVisualStyleBackColor = true;
            this.btnEditar.Click += new System.EventHandler(this.btnEditar_Click);
            // 
            // txtIdEditar
            // 
            this.txtIdEditar.Location = new System.Drawing.Point(8, 24);
            this.txtIdEditar.Name = "txtIdEditar";
            this.txtIdEditar.Size = new System.Drawing.Size(50, 20);
            this.txtIdEditar.TabIndex = 10;
            this.txtIdEditar.TextChanged += new System.EventHandler(this.txtIdEditar_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Código Cliente";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(544, 326);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtIdEditar);
            this.Controls.Add(this.btnEditar);
            this.Controls.Add(this.btnCliente);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Nome);
            this.Controls.Add(this.txtEmailEditar);
            this.Controls.Add(this.txtTelEditar);
            this.Controls.Add(this.txtRgEditar);
            this.Controls.Add(this.txtCpfEditar);
            this.Controls.Add(this.txtEndEditar);
            this.Controls.Add(this.txtNomeEditar);
            this.Controls.Add(this.dataGridViewEditar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEditar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewEditar;
        private System.Windows.Forms.TextBox txtNomeEditar;
        private System.Windows.Forms.TextBox txtEndEditar;
        private System.Windows.Forms.TextBox txtCpfEditar;
        private System.Windows.Forms.TextBox txtRgEditar;
        private System.Windows.Forms.TextBox txtTelEditar;
        private System.Windows.Forms.TextBox txtEmailEditar;
        private System.Windows.Forms.Label Nome;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnCliente;
        private System.Windows.Forms.Button btnEditar;
        private System.Windows.Forms.TextBox txtIdEditar;
        private System.Windows.Forms.Label label1;
    }
}