﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCORRETA
{
    public class Login
    {
        public int Senha { get; private set; }
        public string LoginUsuario { get; private set; }
    }
}
