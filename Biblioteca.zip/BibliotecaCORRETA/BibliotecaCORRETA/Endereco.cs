﻿namespace BibliotecaCORRETA
{
    public class Endereco
    {
        public Cliente Clientes { get; set; }
        public string Rua { get; set; }
        public int Numero { get; set; }
        public string Bairro { get; set; }

    }
}