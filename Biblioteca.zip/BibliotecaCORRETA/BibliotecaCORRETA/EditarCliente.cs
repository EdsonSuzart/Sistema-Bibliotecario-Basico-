﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class EditarCliente : Form
    {
        public EditarCliente()
        {
            InitializeComponent();
        }

        public void EditarCliente_Load(object sender, EventArgs e)
        {

        }

        public void txtNomeEditar_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtRgEditar_TextChanged(object sender, EventArgs e)
        {

        }

        public void txtTelefoneEditar_TextChanged(object sender, EventArgs e)
        {

        }

        public void txtEmailEditar_TextChanged(object sender, EventArgs e)
        {

        }

        public void txtEnderecoEditar_TextChanged(object sender, EventArgs e)
        {

        }

        public void txtCpfEditar_TextChanged(object sender, EventArgs e)
        {

        }
        
        public void EditarClientes()
        {
            Cliente cliente = new Cliente();
            EditarCliente editar = new EditarCliente();
            cliente.Nome = txtNomeEditar.Text;


            using (var contexto = new BibliotecaContexto())
            {
                var existeCliente = contexto.Clientes.Where(x => x.Nome == editar.txtNomeEditar.Text).FirstOrDefault();

                
                contexto.Entry(cliente).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
                
                contexto.SaveChanges();
                

            }

            MessageBox.Show("Dados alterados com SUCESSSO! ");
            this.Hide();

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            EditarClientes();
        }
    }
}
