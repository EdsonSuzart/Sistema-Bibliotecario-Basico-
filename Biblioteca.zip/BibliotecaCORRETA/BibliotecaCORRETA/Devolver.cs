﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class Devolver : Form
    {
        public Devolver()
        {
            InitializeComponent();
        }

        private void dataGridViewDevolucao_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void btnPendencias_Click(object sender, EventArgs e)
        {
            Emprestimo empres = new Emprestimo();


            using (var contexto = new BibliotecaContexto())
                 dataGridViewDevolucao.DataSource = contexto.Emprestimos.ToList();
                    dataGridViewDevolucao.Columns.ToString();
                
              
        }

        private void cbLista_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnDevolver_Click(object sender, EventArgs e)
        {
            DevolverEmprestimo();
        }

        public void DevolverEmprestimo()
        {
            
            Emprestimo e = new Emprestimo();

            using (var contexto = new BibliotecaContexto())
            {

                e.Id = int.Parse(txtDevolverLivro.Text);

                var devolverBook = contexto.Emprestimos.Where(x => x.Id == int.Parse(txtDevolverLivro.Text)).Any();

                if (devolverBook)
                {

                    contexto.Emprestimos.Remove(e);
                    contexto.SaveChanges();
                    MessageBox.Show("Empréstimo devolvido! ");
                }
            }
        }
    }
}
