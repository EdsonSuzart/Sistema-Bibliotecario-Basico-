﻿namespace BibliotecaCORRETA
{
    partial class Devolver
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Devolver));
            this.dataGridViewDevolucao = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnPendencias = new System.Windows.Forms.Button();
            this.txtDevolverLivro = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDevolver = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDevolucao)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewDevolucao
            // 
            this.dataGridViewDevolucao.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dataGridViewDevolucao.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dataGridViewDevolucao.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewDevolucao.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewDevolucao.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewDevolucao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDevolucao.Location = new System.Drawing.Point(12, 37);
            this.dataGridViewDevolucao.Name = "dataGridViewDevolucao";
            this.dataGridViewDevolucao.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dataGridViewDevolucao.Size = new System.Drawing.Size(584, 147);
            this.dataGridViewDevolucao.TabIndex = 0;
            this.dataGridViewDevolucao.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDevolucao_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(218, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "LISTA DE LIVROS EMPRESTADOS";
            // 
            // btnPendencias
            // 
            this.btnPendencias.Location = new System.Drawing.Point(429, 147);
            this.btnPendencias.Name = "btnPendencias";
            this.btnPendencias.Size = new System.Drawing.Size(157, 28);
            this.btnPendencias.TabIndex = 2;
            this.btnPendencias.Text = "Ver Empréstimos Pendentes";
            this.btnPendencias.UseVisualStyleBackColor = true;
            this.btnPendencias.Click += new System.EventHandler(this.btnPendencias_Click);
            // 
            // txtDevolverLivro
            // 
            this.txtDevolverLivro.Location = new System.Drawing.Point(171, 215);
            this.txtDevolverLivro.Name = "txtDevolverLivro";
            this.txtDevolverLivro.Size = new System.Drawing.Size(67, 20);
            this.txtDevolverLivro.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 218);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Cógido do Livro / Devolução:";
            // 
            // btnDevolver
            // 
            this.btnDevolver.Location = new System.Drawing.Point(451, 218);
            this.btnDevolver.Name = "btnDevolver";
            this.btnDevolver.Size = new System.Drawing.Size(145, 45);
            this.btnDevolver.TabIndex = 5;
            this.btnDevolver.Text = "DEVOLVER";
            this.btnDevolver.UseVisualStyleBackColor = true;
            this.btnDevolver.Click += new System.EventHandler(this.btnDevolver_Click);
            // 
            // Devolver
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(608, 275);
            this.Controls.Add(this.btnDevolver);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtDevolverLivro);
            this.Controls.Add(this.btnPendencias);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewDevolucao);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Devolver";
            this.Text = "Devolver";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDevolucao)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewDevolucao;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnPendencias;
        private System.Windows.Forms.TextBox txtDevolverLivro;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnDevolver;
    }
}