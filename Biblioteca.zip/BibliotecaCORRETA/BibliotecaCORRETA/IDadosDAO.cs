﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCORRETA
{
    interface IDadosDAO
    {
        void Adicionar(Livro l);
        void Remover(Livro l);
        void Atualizar(Livro l);
        IList<Livro> Livros();

    }
}
