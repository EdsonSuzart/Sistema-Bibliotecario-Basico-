﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCORRETA
{
    public class BibliotecaContexto : DbContext, IDisposable
    {

        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<Livro> Livros{ get; set; }
        public DbSet<Endereco> Enderecos { get; set; }
        public DbSet<Emprestimo> Emprestimos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=(localdb)\\mssqllocaldb;Database=BibliotecaDB;Trusted_Connection=true;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)//executado na criaçao do modelo
        {

            modelBuilder
                .Entity<Livro>()
                .HasKey(pp => new { pp.IdLivro });

            modelBuilder
                .Entity<Cliente>()
                .HasKey(pp => new { pp.IdCliente });


            modelBuilder
                .Entity<Emprestimo>()
                .HasKey(pp => new { pp.Id});

            modelBuilder
                .Entity<Endereco>()
                .ToTable("Enderecos");

            modelBuilder
                .Entity<Endereco>()
                .Property<int>("ClienteIdCliente");

            modelBuilder
         .Entity<Endereco>()
         .HasKey("ClienteIdCliente");
            base.OnModelCreating(modelBuilder);

            //////////////////////////////////////
        }
    }
}

