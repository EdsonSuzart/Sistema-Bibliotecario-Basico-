﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class FormExcluirLivro : Form
    {
        public FormExcluirLivro()
        {
            InitializeComponent();
        }

        private void dataGridViewLivros_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            Livro livros = new Livro();
            
        }

        public void ExcluirLivro()
        {
            Livro livros = new Livro();


            using (var contexto = new BibliotecaContexto())
            {

                livros.IdLivro = int.Parse(txtExcluirLivro.Text);

                var excluirLivro = contexto.Livros.Where(x => x.IdLivro == int.Parse(txtExcluirLivro.Text)).Any();

                if (excluirLivro)
                {

                    contexto.Livros.Remove(livros);
                    contexto.SaveChanges();
                    MessageBox.Show("Livro Excluído da Base de Dados! ");
                }
            }
        }

        private void tbnExcluirLivro_Click(object sender, EventArgs e)
        {
            ExcluirLivro();
        }

        private void tbnListaLivros_Click(object sender, EventArgs e)
        {
            using(var contexto = new BibliotecaContexto())
                dataGridViewLivros.DataSource = contexto.Livros.ToList();
        }
    }
}
