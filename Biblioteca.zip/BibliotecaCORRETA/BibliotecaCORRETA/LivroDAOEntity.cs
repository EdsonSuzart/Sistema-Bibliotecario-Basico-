﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaCORRETA
{
    public class LivroDAOEntity : IDadosDAO, IDisposable
    {

        public BibliotecaContexto contexto;

        public void Adicionar(Livro l)
        {
            contexto.Livros.Add(l);
            contexto.SaveChanges();
        }

        public void Atualizar(Livro l)
        {
            contexto.Livros.Add(l);
            contexto.SaveChanges();
        }

        public void Dispose()
        {
            contexto.Dispose();
        }

        public IList<Livro> Livros()
        {
            return contexto.Livros.ToList();
        }

        public void Remover(Livro l)
        {
            contexto.Livros.Add(l);
            contexto.SaveChanges();
        }
    }
}
