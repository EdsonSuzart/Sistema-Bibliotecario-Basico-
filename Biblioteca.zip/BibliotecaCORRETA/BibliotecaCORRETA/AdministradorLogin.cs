﻿namespace BibliotecaCORRETA
{
    public class AdministradorLogin
    {

        public string Senha { get; set; }


        public bool Autenticar(string senha)
        {
            return this.Senha == senha;
        }
    }
}