﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class FormAddLivros : Form
    {
        public FormAddLivros()
        {
            InitializeComponent();
        }

        private void txtEndereco_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSalvarLivro_Click(object sender, EventArgs e)
        {
            InserirDadosCliente();
        }


        public void InserirDadosCliente()
        {

            Livro livro = new Livro();
            //livro.IdLivro = int.Parse(txtCodigo.Text);
            //scliente.EnderecoCliente = txtEndereco.Text;
            livro.Nome = txtNomeLivro.Text;
            livro.Autor = txtAutor.Text;
            
            using (var contexto = new BibliotecaContexto())
            {
                
                var existeId = contexto.Clientes.Where(x => x.IdCliente == livro.IdLivro).Any();

                if (existeId)
                {
                    //já existe.
                    MessageBox.Show("Dados ja salvos! Insira novamente os dados. ");
                    this.Hide();

                }

                else
                {

                    contexto.Livros.Add(livro);
                    contexto.SaveChanges();
                    Console.WriteLine("Dados Inseridos no banco com sucesso! ");
                    MessageBox.Show("Dados Salvos com sucesso! ");

                }

              
                txtNomeLivro.Text = String.Empty;
                txtAutor.Text = String.Empty;
               

            }
        }

        private void txtCodigo_TextChanged(object sender, EventArgs e)
        {

        }

        private void FormAddLivros_Load(object sender, EventArgs e)
        {

        }
    }
}
