﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class MenuDados : Form
    {

        public static MenuDados mn;
        public MenuDados()
        {
            InitializeComponent();


        }

        public void label1_Click(object sender, EventArgs e)
        {

        }

        public void cadastrarNovoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 cadastroCliente = new Form1();
            cadastroCliente.Show();
           
        }

        public void consultarCadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAddLivros mostrarCliente = new FormAddLivros();
            mostrarCliente.Show();
        }

        public void cadastrarLivroToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        public void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        public void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void editarClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 editar = new Form2();
            editar.Show();
        }

        public void emprestarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EmprestarLivro emprestaCamarada = new EmprestarLivro();
            emprestaCamarada.Show();
        }

        public void excluirClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormExcluir form = new FormExcluir();
            form.Show();
        }

        public void MenuDados_Load(object sender, EventArgs e)
        {
            menuOpcoes.Enabled = false;
            
        }

        public void excluirLivroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormExcluirLivro form = new FormExcluirLivro();
            form.Show();
        }

        public void devolverToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Devolver devolve = new Devolver();
            devolve.Show();
        }

        public void editarLivroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EditarLivro editar = new EditarLivro();
            editar.Show();
        }

        public void logarNoSistemaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            telaL login = new telaL();
            login.Show();
        }

        public void menuOpcoes_ItemClicked(object sender, EventArgs e)
        {
            //menuOpcoes.Enabled = true;
        }

        public void menuStrip2_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        public void menuOpcoes_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
        }
    }
}
