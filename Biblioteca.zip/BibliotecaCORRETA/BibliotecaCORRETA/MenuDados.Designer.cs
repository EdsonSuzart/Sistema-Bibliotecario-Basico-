﻿namespace BibliotecaCORRETA
{
    partial class MenuDados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MenuDados));
            this.menuOpcoes = new System.Windows.Forms.MenuStrip();
            this.clientes = new System.Windows.Forms.ToolStripMenuItem();
            this.cadastrarNovoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarCadastroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editar = new System.Windows.Forms.ToolStripMenuItem();
            this.editarClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editarLivroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excluir = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirClienteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.excluirLivroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.emprestar = new System.Windows.Forms.ToolStripMenuItem();
            this.devolver = new System.Windows.Forms.ToolStripMenuItem();
            this.relatorio = new System.Windows.Forms.ToolStripMenuItem();
            this.relatórioDeLivrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.relatóriosDeLivrosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sairToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.menuOpcoes.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuOpcoes
            // 
            this.menuOpcoes.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuOpcoes.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clientes,
            this.editar,
            this.excluir,
            this.emprestar,
            this.devolver,
            this.relatorio,
            this.sairToolStripMenuItem});
            this.menuOpcoes.Location = new System.Drawing.Point(0, 0);
            this.menuOpcoes.Name = "menuOpcoes";
            this.menuOpcoes.Size = new System.Drawing.Size(597, 24);
            this.menuOpcoes.TabIndex = 0;
            this.menuOpcoes.Text = "menuStrip";
            this.menuOpcoes.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuOpcoes_ItemClicked);
            // 
            // clientes
            // 
            this.clientes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cadastrarNovoToolStripMenuItem,
            this.consultarCadastroToolStripMenuItem});
            this.clientes.Name = "clientes";
            this.clientes.Size = new System.Drawing.Size(69, 20);
            this.clientes.Text = "Cadastrar";
            this.clientes.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
            // 
            // cadastrarNovoToolStripMenuItem
            // 
            this.cadastrarNovoToolStripMenuItem.Name = "cadastrarNovoToolStripMenuItem";
            this.cadastrarNovoToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.cadastrarNovoToolStripMenuItem.Text = "Cadastrar Cliente";
            this.cadastrarNovoToolStripMenuItem.Click += new System.EventHandler(this.cadastrarNovoToolStripMenuItem_Click);
            // 
            // consultarCadastroToolStripMenuItem
            // 
            this.consultarCadastroToolStripMenuItem.Name = "consultarCadastroToolStripMenuItem";
            this.consultarCadastroToolStripMenuItem.Size = new System.Drawing.Size(164, 22);
            this.consultarCadastroToolStripMenuItem.Text = "Cadastrar Livro";
            this.consultarCadastroToolStripMenuItem.Click += new System.EventHandler(this.consultarCadastroToolStripMenuItem_Click);
            // 
            // editar
            // 
            this.editar.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editarClienteToolStripMenuItem,
            this.editarLivroToolStripMenuItem});
            this.editar.Name = "editar";
            this.editar.Size = new System.Drawing.Size(49, 20);
            this.editar.Text = "Editar";
            // 
            // editarClienteToolStripMenuItem
            // 
            this.editarClienteToolStripMenuItem.Name = "editarClienteToolStripMenuItem";
            this.editarClienteToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.editarClienteToolStripMenuItem.Text = "Editar Cliente";
            this.editarClienteToolStripMenuItem.Click += new System.EventHandler(this.editarClienteToolStripMenuItem_Click);
            // 
            // editarLivroToolStripMenuItem
            // 
            this.editarLivroToolStripMenuItem.Name = "editarLivroToolStripMenuItem";
            this.editarLivroToolStripMenuItem.Size = new System.Drawing.Size(144, 22);
            this.editarLivroToolStripMenuItem.Text = "Editar Livro";
            this.editarLivroToolStripMenuItem.Click += new System.EventHandler(this.editarLivroToolStripMenuItem_Click);
            // 
            // excluir
            // 
            this.excluir.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.excluirClienteToolStripMenuItem,
            this.excluirLivroToolStripMenuItem});
            this.excluir.Name = "excluir";
            this.excluir.Size = new System.Drawing.Size(53, 20);
            this.excluir.Text = "Excluir";
            // 
            // excluirClienteToolStripMenuItem
            // 
            this.excluirClienteToolStripMenuItem.Name = "excluirClienteToolStripMenuItem";
            this.excluirClienteToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.excluirClienteToolStripMenuItem.Text = "Excluir Cliente";
            this.excluirClienteToolStripMenuItem.Click += new System.EventHandler(this.excluirClienteToolStripMenuItem_Click);
            // 
            // excluirLivroToolStripMenuItem
            // 
            this.excluirLivroToolStripMenuItem.Name = "excluirLivroToolStripMenuItem";
            this.excluirLivroToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.excluirLivroToolStripMenuItem.Text = "Excluir Livro";
            this.excluirLivroToolStripMenuItem.Click += new System.EventHandler(this.excluirLivroToolStripMenuItem_Click);
            // 
            // emprestar
            // 
            this.emprestar.Name = "emprestar";
            this.emprestar.Size = new System.Drawing.Size(72, 20);
            this.emprestar.Text = "Emprestar";
            this.emprestar.Click += new System.EventHandler(this.emprestarToolStripMenuItem_Click);
            // 
            // devolver
            // 
            this.devolver.Name = "devolver";
            this.devolver.Size = new System.Drawing.Size(65, 20);
            this.devolver.Text = "Devolver";
            this.devolver.Click += new System.EventHandler(this.devolverToolStripMenuItem_Click);
            // 
            // relatorio
            // 
            this.relatorio.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.relatórioDeLivrosToolStripMenuItem,
            this.relatóriosDeLivrosToolStripMenuItem});
            this.relatorio.Name = "relatorio";
            this.relatorio.Size = new System.Drawing.Size(66, 20);
            this.relatorio.Text = "Relatório";
            // 
            // relatórioDeLivrosToolStripMenuItem
            // 
            this.relatórioDeLivrosToolStripMenuItem.Name = "relatórioDeLivrosToolStripMenuItem";
            this.relatórioDeLivrosToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.relatórioDeLivrosToolStripMenuItem.Text = "Relatório de Clientes";
            // 
            // relatóriosDeLivrosToolStripMenuItem
            // 
            this.relatóriosDeLivrosToolStripMenuItem.Name = "relatóriosDeLivrosToolStripMenuItem";
            this.relatóriosDeLivrosToolStripMenuItem.Size = new System.Drawing.Size(182, 22);
            this.relatóriosDeLivrosToolStripMenuItem.Text = "Relatórios de Livros";
            // 
            // sairToolStripMenuItem
            // 
            this.sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            this.sairToolStripMenuItem.Size = new System.Drawing.Size(38, 20);
            this.sairToolStripMenuItem.Text = "Sair";
            this.sairToolStripMenuItem.Click += new System.EventHandler(this.sairToolStripMenuItem_Click);
            // 
            // label1
            // 
            this.label1.AllowDrop = true;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(217, 290);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 27);
            this.label1.TabIndex = 1;
            this.label1.Text = "Olá! Bem vindo.";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // MenuDados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BibliotecaCORRETA.Properties.Resources.download1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(597, 326);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuOpcoes);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuOpcoes;
            this.Name = "MenuDados";
            this.Text = "Menu Inicial";
            this.Load += new System.EventHandler(this.MenuDados_Load);
            this.menuOpcoes.ResumeLayout(false);
            this.menuOpcoes.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStripMenuItem clientes;
        private System.Windows.Forms.ToolStripMenuItem cadastrarNovoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarCadastroToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem editar;
        private System.Windows.Forms.ToolStripMenuItem excluir;
        private System.Windows.Forms.ToolStripMenuItem editarClienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editarLivroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excluirClienteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem excluirLivroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem emprestar;
        private System.Windows.Forms.ToolStripMenuItem devolver;
        private System.Windows.Forms.ToolStripMenuItem relatorio;
        private System.Windows.Forms.ToolStripMenuItem relatórioDeLivrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem relatóriosDeLivrosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem;
        private System.Windows.Forms.ImageList imageList1;
        public System.Windows.Forms.MenuStrip menuOpcoes;
    }
}