﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class EmprestarLivro : Form
    {
        public EmprestarLivro()
        {
            InitializeComponent();
        }

        private void dataGridViewLivros_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            Int32 IdLivro = (Int32)dataGridViewLivros.CurrentRow.Cells[0].Value;
            String Nome = dataGridViewLivros.CurrentRow.Cells[1].Value.ToString();
            String Autor = dataGridViewLivros.CurrentRow.Cells[2].Value.ToString();

            MessageBox.Show(Nome.ToString(), "\n");

        }

        private void btnVer_Click(object sender, EventArgs e)
        {
            ReceberLivrosBanco();
        }

        public void ReceberLivrosBanco()
        {

            using (var contexto = new BibliotecaContexto())
            {
                Livro livro = new Livro();
                dataGridViewLivros.DataSource = contexto.Livros.ToList();

            }
        }

        private void txtData_TextChanged(object sender, EventArgs e)
        {


        }

        private void EmprestarLivro_Load(object sender, EventArgs e)
        {
            txtData.Text = DateTime.Now.ToString("dd/MM/yyyy");
            txtHora.Text = DateTime.Now.ToString("HH:mm:ss");

        }

        private void tbnEmprestar_Click(object sender, EventArgs e)
        {

            VerificarLivroECadastro();


        }


        private void VerificarLivroECadastro()
        {
            Cliente cliente = new Cliente();
            Livro livros = new Livro();
            Emprestimo emprestar = new Emprestimo();
            emprestar.Cpf = txtCpfEmprestar.Text;
            emprestar.Nome = txtNomeEmprestar.Text;
            emprestar.CodigoLivro = int.Parse(txtIdLivro.Text);
            emprestar.NomeLivro = txtNomeLivro.Text;
            emprestar.Data = DateTime.Now;
            emprestar.Hora = DateTime.Now;

            using (var contexto = new BibliotecaContexto())
            {
                
                var existeCadastro = contexto.Clientes.Where(x => x.Cpf == emprestar.Cpf).Any();
                var salvarIdLivro = contexto.Livros.Where(x=> x.IdLivro == emprestar.CodigoLivro).Any();
                var salvarNomeLivro = contexto.Livros.Where(x => x.Nome == emprestar.NomeLivro).Any();
                var verificarDispoLivro = contexto.Emprestimos.Where(l => l.CodigoLivro == emprestar.CodigoLivro).Any();

                if (verificarDispoLivro)
                {
                    MessageBox.Show("Livro nao disponivel! ");
                    this.Hide();
                }
                else { 

                if (existeCadastro && salvarIdLivro || salvarNomeLivro)
                     {
                            contexto.Emprestimos.Add(emprestar);


                            MessageBox.Show("Empréstimo realizado com sucesso! ");



                            txtCpfEmprestar.Text = String.Empty;
                            txtNomeEmprestar.Text = String.Empty;
                            txtData.Text = String.Empty;
                            txtHora.Text = String.Empty;

                        }

                        else
                        {
                            MessageBox.Show("Empréstimo não realizado. \n Cliente ainda não cadastrado na Base de Dados!  ");
                            this.Hide();


                        }
                        contexto.SaveChanges();
                }

            }
            


        }

        private void txtTeste_TextChanged(object sender, EventArgs e)
        {


        }

        private void txtIdLivro_TextChanged(object sender, EventArgs e)
        {

        }
    }
}



 