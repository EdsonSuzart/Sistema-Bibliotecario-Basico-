﻿namespace BibliotecaCORRETA
{
    partial class EmprestarLivro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EmprestarLivro));
            this.dataGridViewLivros = new System.Windows.Forms.DataGridView();
            this.txtCpfEmprestar = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNomeEmprestar = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbnEmprestar = new System.Windows.Forms.Button();
            this.btnVer = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtIdLivro = new System.Windows.Forms.TextBox();
            this.txtNomeLivro = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLivros)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewLivros
            // 
            this.dataGridViewLivros.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dataGridViewLivros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLivros.Location = new System.Drawing.Point(12, 31);
            this.dataGridViewLivros.Name = "dataGridViewLivros";
            this.dataGridViewLivros.Size = new System.Drawing.Size(619, 201);
            this.dataGridViewLivros.TabIndex = 0;
            this.dataGridViewLivros.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewLivros_CellContentClick);
            // 
            // txtCpfEmprestar
            // 
            this.txtCpfEmprestar.Location = new System.Drawing.Point(12, 327);
            this.txtCpfEmprestar.Name = "txtCpfEmprestar";
            this.txtCpfEmprestar.Size = new System.Drawing.Size(160, 20);
            this.txtCpfEmprestar.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 308);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "CPF do Cliente";
            // 
            // txtNomeEmprestar
            // 
            this.txtNomeEmprestar.Location = new System.Drawing.Point(12, 272);
            this.txtNomeEmprestar.Name = "txtNomeEmprestar";
            this.txtNomeEmprestar.Size = new System.Drawing.Size(238, 20);
            this.txtNomeEmprestar.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nome do Cliente";
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(201, 327);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(78, 20);
            this.txtData.TabIndex = 5;
            this.txtData.TextChanged += new System.EventHandler(this.txtData_TextChanged);
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(354, 327);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(57, 20);
            this.txtHora.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(201, 308);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Data do Empréstimo";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(354, 308);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Hora do Empréstimo";
            // 
            // tbnEmprestar
            // 
            this.tbnEmprestar.Location = new System.Drawing.Point(500, 327);
            this.tbnEmprestar.Name = "tbnEmprestar";
            this.tbnEmprestar.Size = new System.Drawing.Size(131, 44);
            this.tbnEmprestar.TabIndex = 9;
            this.tbnEmprestar.Text = "Emprestar";
            this.tbnEmprestar.UseVisualStyleBackColor = true;
            this.tbnEmprestar.Click += new System.EventHandler(this.tbnEmprestar_Click);
            // 
            // btnVer
            // 
            this.btnVer.Location = new System.Drawing.Point(500, 199);
            this.btnVer.Name = "btnVer";
            this.btnVer.Size = new System.Drawing.Size(120, 23);
            this.btnVer.TabIndex = 10;
            this.btnVer.Text = "Ver Livros";
            this.btnVer.UseVisualStyleBackColor = true;
            this.btnVer.Click += new System.EventHandler(this.btnVer_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(303, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 13);
            this.label5.TabIndex = 11;
            this.label5.Text = "Código livro Desejado";
            // 
            // txtIdLivro
            // 
            this.txtIdLivro.Location = new System.Drawing.Point(306, 272);
            this.txtIdLivro.Name = "txtIdLivro";
            this.txtIdLivro.Size = new System.Drawing.Size(55, 20);
            this.txtIdLivro.TabIndex = 12;
            this.txtIdLivro.TextChanged += new System.EventHandler(this.txtIdLivro_TextChanged);
            // 
            // txtNomeLivro
            // 
            this.txtNomeLivro.Location = new System.Drawing.Point(442, 272);
            this.txtNomeLivro.Name = "txtNomeLivro";
            this.txtNomeLivro.Size = new System.Drawing.Size(164, 20);
            this.txtNomeLivro.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(442, 253);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(124, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Nome do Livro Desejado";
            // 
            // EmprestarLivro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ClientSize = new System.Drawing.Size(643, 381);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtNomeLivro);
            this.Controls.Add(this.txtIdLivro);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnVer);
            this.Controls.Add(this.tbnEmprestar);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNomeEmprestar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtCpfEmprestar);
            this.Controls.Add(this.dataGridViewLivros);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "EmprestarLivro";
            this.Text = "EmprestarLivro";
            this.Load += new System.EventHandler(this.EmprestarLivro_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLivros)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewLivros;
        private System.Windows.Forms.TextBox txtCpfEmprestar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNomeEmprestar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button tbnEmprestar;
        private System.Windows.Forms.Button btnVer;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtIdLivro;
        private System.Windows.Forms.TextBox txtNomeLivro;
        private System.Windows.Forms.Label label6;
    }
}