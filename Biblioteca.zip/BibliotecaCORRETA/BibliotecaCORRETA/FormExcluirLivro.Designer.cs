﻿namespace BibliotecaCORRETA
{
    partial class FormExcluirLivro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormExcluirLivro));
            this.dataGridViewLivros = new System.Windows.Forms.DataGridView();
            this.txtExcluirLivro = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbnExcluirLivro = new System.Windows.Forms.Button();
            this.tbnListaLivros = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLivros)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewLivros
            // 
            this.dataGridViewLivros.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewLivros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLivros.Location = new System.Drawing.Point(22, 41);
            this.dataGridViewLivros.Name = "dataGridViewLivros";
            this.dataGridViewLivros.Size = new System.Drawing.Size(379, 156);
            this.dataGridViewLivros.TabIndex = 0;
            this.dataGridViewLivros.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewLivros_CellContentClick);
            // 
            // txtExcluirLivro
            // 
            this.txtExcluirLivro.Location = new System.Drawing.Point(184, 234);
            this.txtExcluirLivro.Name = "txtExcluirLivro";
            this.txtExcluirLivro.Size = new System.Drawing.Size(52, 20);
            this.txtExcluirLivro.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Código do Livro para ser excluído:";
            // 
            // tbnExcluirLivro
            // 
            this.tbnExcluirLivro.Location = new System.Drawing.Point(272, 234);
            this.tbnExcluirLivro.Name = "tbnExcluirLivro";
            this.tbnExcluirLivro.Size = new System.Drawing.Size(129, 40);
            this.tbnExcluirLivro.TabIndex = 3;
            this.tbnExcluirLivro.Text = "Excluir Livro";
            this.tbnExcluirLivro.UseVisualStyleBackColor = true;
            this.tbnExcluirLivro.Click += new System.EventHandler(this.tbnExcluirLivro_Click);
            // 
            // tbnListaLivros
            // 
            this.tbnListaLivros.Location = new System.Drawing.Point(281, 163);
            this.tbnListaLivros.Name = "tbnListaLivros";
            this.tbnListaLivros.Size = new System.Drawing.Size(106, 23);
            this.tbnListaLivros.TabIndex = 4;
            this.tbnListaLivros.Text = "Ver Livros";
            this.tbnListaLivros.UseVisualStyleBackColor = true;
            this.tbnListaLivros.Click += new System.EventHandler(this.tbnListaLivros_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(148, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "LISTA DE LIVROS ";
            // 
            // FormExcluirLivro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.ClientSize = new System.Drawing.Size(413, 286);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbnListaLivros);
            this.Controls.Add(this.tbnExcluirLivro);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtExcluirLivro);
            this.Controls.Add(this.dataGridViewLivros);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormExcluirLivro";
            this.Text = "FormExcluirLivro";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLivros)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewLivros;
        private System.Windows.Forms.TextBox txtExcluirLivro;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button tbnExcluirLivro;
        private System.Windows.Forms.Button tbnListaLivros;
        private System.Windows.Forms.Label label2;
    }
}