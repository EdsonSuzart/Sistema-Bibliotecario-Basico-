﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BibliotecaCORRETA;

namespace BibliotecaCORRETA
{
    public partial class Form1 : Form
    {
        
       
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
           

        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            InserirDadosCliente();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void RemoverDadosCliente()
        {
            using (var contexto = new BibliotecaContexto())
            {
                var clientes = contexto.Clientes.ToList();
                foreach (var item in clientes)
                {
                    Console.WriteLine("Trazendo dados do banco: " + item);
                    contexto.Clientes.Remove(item);
                    contexto.SaveChanges();
                }

                Console.WriteLine("Removido com sucesso! ");
            }
        }


        public void InserirDadosCliente()
        {

            Cliente cliente = new Cliente();
            //scliente.EnderecoCliente = txtEndereco.Text;
            cliente.Nome = txtNome.Text;
            cliente.Cpf = txtCpf.Text;
            cliente.Rg = int.Parse(txtRg.Text);
            cliente.Tel = txtTelefone.Text;
            cliente.Email = txtEmail.Text;

            using (var contexto = new BibliotecaContexto())
            {
                Cliente c = new Cliente();

                var existeCPF = contexto.Clientes.Where(x => x.Cpf == cliente.Cpf).Any();

                if (existeCPF)
                {
                    //já existe.
                    MessageBox.Show("CPF já cadastrado na Base de Dados! ");
                    this.Hide();

                }

                else
                {

                    contexto.Clientes.Add(cliente);
                    contexto.SaveChanges();
                    MessageBox.Show("Dados Salvos com sucesso! ");
                    

                }

                txtNome.Text = String.Empty;
                txtEndereco.Text = String.Empty;
                txtEmail.Text = String.Empty;
                txtCpf.Text = String.Empty;
                txtRg.Text = String.Empty;
                txtTelefone.Text = String.Empty;

               

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            RemoverDadosCliente();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {

        }


       
    }
}
