﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class EditarLivro : Form
    {

        int poc;

        public EditarLivro()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLivroEditar_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            poc = dataGridViewLivro.CurrentRow.Index;

            txtCodigoEditar.Text = dataGridViewLivro[0, poc].Value.ToString();
            txtLivroEditar.Text = dataGridViewLivro[1, poc].Value.ToString();
            //txtEndEditar.Text = dataGridViewEditar[2, poc].Value.ToString();
            txtAutorEditar.Text = dataGridViewLivro[2, poc].Value.ToString();

        }

        private void tbnLivros_Click(object sender, EventArgs e)
        {
            using (var contexto = new BibliotecaContexto())
                dataGridViewLivro.DataSource = contexto.Livros.ToList();

        }

        private void txtCodigoEditar_TextChanged(object sender, EventArgs e)
        {
            txtCodigoEditar.Enabled = false;
        }

        private void btnEditarLivro_Click(object sender, EventArgs e)
        {
            BtnEditarLivro();
        }

        public void BtnEditarLivro()
        {
            using (var contexto = new BibliotecaContexto())
            {

                Livro livros = contexto.Livros.Find(Convert.ToInt32(txtCodigoEditar.Text));

                poc = dataGridViewLivro.CurrentRow.Index;
                dataGridViewLivro[1, poc].Value = txtLivroEditar.Text;
                dataGridViewLivro[2, poc].Value = txtAutorEditar.Text;


                livros.Nome = txtLivroEditar.Text;
                livros.Autor = txtAutorEditar.Text;



                contexto.SaveChanges();
            }
        }
    }
}
