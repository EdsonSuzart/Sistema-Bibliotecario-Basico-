﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class FormExcluir : Form
    {
        public FormExcluir()
        {
            InitializeComponent();
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            ExcluirCliente();
        }

        public void ExcluirCliente() {


            Cliente cliente = new Cliente();
            FormExcluir form = new FormExcluir();



            using (var contexto = new BibliotecaContexto()) {
             
                cliente.IdCliente = int.Parse(txtIdExcluir.Text);

                var excluirCliente = contexto.Clientes.Where(x => x.IdCliente == int.Parse(txtIdExcluir.Text)).Any();

                if (excluirCliente) {

                    contexto.Clientes.Remove(cliente);
                    contexto.SaveChanges();
                    MessageBox.Show("Cliente Excluído da Base de Dados! ");
                }
             }
        }

        private void btnListaClientes_Click(object sender, EventArgs e)
        {
            using (var contexto = new BibliotecaContexto())
                dataGridViewLista.DataSource = contexto.Clientes.ToList();
        }

        private void dataGridViewLista_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        
    }
}
