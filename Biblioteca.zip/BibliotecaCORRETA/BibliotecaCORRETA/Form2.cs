﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class Form2 : Form
    {

        int poc;

        public Form2()
        {
            InitializeComponent();
        }

        private void dataGridViewEditar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            poc = dataGridViewEditar.CurrentRow.Index;

            txtIdEditar.Text = dataGridViewEditar[0, poc].Value.ToString();
            txtNomeEditar.Text = dataGridViewEditar[1, poc].Value.ToString();
            //txtEndEditar.Text = dataGridViewEditar[2, poc].Value.ToString();
            txtEmailEditar.Text = dataGridViewEditar[6, poc].Value.ToString();
            txtCpfEditar.Text = dataGridViewEditar[3, poc].Value.ToString();
            txtRgEditar.Text = dataGridViewEditar[4, poc].Value.ToString();
            txtTelEditar.Text = dataGridViewEditar[5, poc].Value.ToString();


        }

        private void btnCliente_Click(object sender, EventArgs e)
        {
            using (var contexto = new BibliotecaContexto())
                dataGridViewEditar.DataSource = contexto.Clientes.ToList();
        }

        public void BtnEditar()
        {
            using (var contexto = new BibliotecaContexto()) {
               
                Cliente cliente = contexto.Clientes.Find(Convert.ToInt32(txtIdEditar.Text));
               
                poc = dataGridViewEditar.CurrentRow.Index;
                dataGridViewEditar[1, poc].Value = txtNomeEditar.Text;
                dataGridViewEditar[6, poc].Value = txtEmailEditar.Text;
                dataGridViewEditar[3, poc].Value = txtCpfEditar.Text;
                dataGridViewEditar[4, poc].Value = int.Parse(txtRgEditar.Text);
                dataGridViewEditar[5, poc].Value = txtTelEditar.Text;

                cliente.Nome = txtNomeEditar.Text;
                cliente.Cpf = txtCpfEditar.Text;
                cliente.Rg = int.Parse(txtRgEditar.Text);
                cliente.Tel = txtTelEditar.Text;
                cliente.Email = txtEmailEditar.Text;
                

                contexto.SaveChanges();
            }


        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            BtnEditar();
        }

        private void txtIdEditar_TextChanged(object sender, EventArgs e)
        {
            txtIdEditar.Enabled = false;
        }
    }
}
