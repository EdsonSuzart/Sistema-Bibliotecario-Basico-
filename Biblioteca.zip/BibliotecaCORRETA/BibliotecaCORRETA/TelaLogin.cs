﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BibliotecaCORRETA
{
    public partial class telaL : Form
    {
        public telaL()
        {
            InitializeComponent();
        }

        public void btnLogar_Click(object sender, EventArgs e)
        {

            telaL login = new telaL();
            login.txtUsuarioLogar.Text = "admin";
            login.txtSenhaLogar.Text = "123";
            MenuDados menu = new MenuDados();
          

            if (txtUsuarioLogar.Text == "admin" && txtSenhaLogar.Text == "123")
            {
                MessageBox.Show("Dados Corretos! \n Bem vindo ao Sistema! ");
                txtUsuarioLogar.Text = String.Empty;
                txtSenhaLogar.Text = String.Empty;
                this.Hide();
                //Enabled = false;
                menu.Show();
                menu.menuOpcoes.Enabled = true;
                login.Enabled = false;


            }

            else
            {
                MessageBox.Show("Usuário ou senha incorretos! ");
                txtUsuarioLogar.Text = String.Empty;
                txtSenhaLogar.Text = String.Empty;
               

            }
        }

        private void TelaLogin_Load(object sender, EventArgs e)
        {
            
        }
    }
}
